package com.example.finalproject.ui


import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.finalproject.data.FavoritesRepository
import com.example.finalproject.data.RecipeDatabase
import com.example.finalproject.model.RecipeEntity
import com.example.finalproject.data.RecipeRepository
import com.example.finalproject.network.RecipeScraper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup

class RecipeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: RecipeRepository
    private val favoritesRepository: FavoritesRepository

    val recipes = RecipeDatabase.getDatabase(application).recipeDao()
        .getAllRecipes()
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

    init {
        val dao = RecipeDatabase.getDatabase(application).recipeDao()
        repository = RecipeRepository(dao)
        favoritesRepository = FavoritesRepository(dao)
    }

    fun addRecipeFromUrl(url: String) {
        viewModelScope.launch {
            val details = RecipeScraper.fetchRecipeDetails(url)

            val recipe = RecipeEntity(
                title = details.title,
                description = details.description,
                difficulty = "Auto",
                imageUrl = details.imageUrl,
                url = details.sourceUrl,
                ingredients = details.ingredients.joinToString("\n"),
                instructions = details.instructions.joinToString("\n")
            )

            repository.insertRecipe(recipe)
        }
    }

    fun deleteRecipe(recipe: RecipeEntity) = viewModelScope.launch {
        repository.deleteRecipe(recipe)
    }

    suspend fun getRecipeById(id: Int): RecipeEntity? = repository.getRecipeById(id)

    fun toggleFavorite(recipe: RecipeEntity) = viewModelScope.launch {
        favoritesRepository.toggleFavorite(recipe)
    }

    suspend fun extractImageFromUrl(url: String): String? = withContext(Dispatchers.IO) {
        try {
            val doc = Jsoup.connect(url).get()
            doc.select("meta[property=og:image]").attr("content").ifEmpty { null }
        } catch (e: Exception) {
            null
        }
    }

    fun addRecipeFromUrl(title: String, url: String, imageResId: String? = null) {
        viewModelScope.launch {
            val details = RecipeScraper.fetchRecipeDetails(url)

            val recipe = RecipeEntity(
                title = details.title,
                description = details.description,
                difficulty = "Easy",
                imageUrl = details.imageUrl,
                url = details.sourceUrl,
                ingredients = details.ingredients.joinToString("\n"),
                instructions = details.instructions.joinToString("\n")
            )

            repository.insertRecipe(recipe)

            println("SAVED TO DB: ${recipe.title}")
        }
    }
}