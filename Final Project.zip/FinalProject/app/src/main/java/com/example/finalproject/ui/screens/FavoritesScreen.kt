package com.example.finalproject.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.*
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.finalproject.RecipeCard
import com.example.finalproject.data.FavoritesRepository
import com.example.finalproject.model.RecipeEntity
import com.example.finalproject.ui.RecipeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FavoritesScreen(
    recipeViewModel: RecipeViewModel = viewModel(),
    favoritesRepository: FavoritesRepository,
    onRecipeDoubleClick: (RecipeEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val favorites by favoritesRepository.favorites.collectAsState(initial = emptyList())

    Scaffold { innerPadding ->
        if (favorites.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Text("No favorites yet!")
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                items(favorites) { recipe ->
                    val isFavorite = favorites.any { it.id == recipe.id }

                    RecipeCard(
                        recipe = recipe,
                        onDoubleClick = { onRecipeDoubleClick(recipe) },
                        onToggleFavorite = { recipeViewModel.toggleFavorite(recipe) },
                        isFavorite = isFavorite,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }
}