package com.example.finalproject.data

import com.example.finalproject.model.RecipeEntity
import kotlinx.coroutines.flow.Flow

class FavoritesRepository(private val recipeDao: RecipeDao) {

    val favorites: Flow<List<RecipeEntity>> = recipeDao.getFavorites()

    suspend fun toggleFavorite(recipe: RecipeEntity) {
        val newStatus = !recipe.isFavorite
        recipeDao.updateFavoriteStatus(recipe.id, newStatus)
    }

    suspend fun setFavorite(recipeId: Int, isFavorite: Boolean) {
        recipeDao.updateFavoriteStatus(recipeId, isFavorite)
    }
}