package com.example.finalproject

import android.app.Application
import androidx.room.Room
import com.example.finalproject.data.RecipeDatabase
import com.example.finalproject.data.RecipeRepository

class RecipeApplication : Application() {
    val database by lazy { RecipeDatabase.getDatabase(this) }
    val repository by lazy { RecipeRepository(database.recipeDao()) }
}