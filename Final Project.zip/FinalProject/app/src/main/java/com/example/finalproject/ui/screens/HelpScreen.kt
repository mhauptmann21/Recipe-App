package com.example.finalproject.ui.screens


import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController


@Composable
fun HelpScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Tips & Tricks", style = MaterialTheme.typography.titleLarge)

        Spacer(Modifier.height(16.dp))

        Text("• Double-tap a recipe card to see full details.")
        Spacer(Modifier.height(15.dp))
        Text("• Use the Settings page to enable Dark Mode.")
        Spacer(Modifier.height(15.dp))
        Text("• Tap the back arrow in the top bar to return to the previous screen.")
        Spacer(Modifier.height(15.dp))
        Text("• Access this Help page anytime from the top bar.")
    }
}