package com.example.finalproject.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.finalproject.ui.RecipeViewModel


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddRecipeScreen(
    navController: NavController,
    onAddRecipe: (String, String) -> Unit
) {
    var title by remember { mutableStateOf(TextFieldValue("")) }
    var url by remember { mutableStateOf(TextFieldValue("")) }
    var imageResId by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Add a New Recipe",
            style = MaterialTheme.typography.headlineSmall
        )
        TextField(
            value = title,
            onValueChange = { title = it},
            label = { Text("Recipe Title (optional)") },
            modifier = Modifier.fillMaxWidth()
        )
        TextField(
            value = url,
            onValueChange = { url = it },
            label = { Text("Recipe URL") },
            modifier = Modifier.fillMaxWidth()
        )

        TextField(
            value = imageResId,
            onValueChange = { imageResId = it },
            label = { Text("Image URL (optional)") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                if (url.text.isNotBlank()) {
                    onAddRecipe(title.text, url.text)

                    navController.popBackStack()
                }
            },
            modifier = Modifier.align(Alignment.End)
        ) {
            Text("Save Recipe")
        }
    }
}
