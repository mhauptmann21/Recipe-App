package com.example.finalproject.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.*


val Green = Color(0xFF9CAF88)
val LightBeige = Color(0xFFf2e8cf)
val LightPink = Color(0xFFFFA5AB)
val MediumPink = Color(0xFFda627d)
val DarkPink = Color(0xFFa53860)
val Burgundy = Color (0xFF450920)
val Yellow = Color(0xFFC39414)
val Red = Color(0xFFBF7E81)
val Black = Color(0xFF000000)
val White = Color(0xFFFFFFFF)



private val LightColors = lightColorScheme(
    primary = LightPink,          // Top app bar text
    background = LightBeige,  // Background
    surface = White,      // Card background
    onPrimary = Burgundy,        // Title bar text color
    onSurface = Black,        // Default text in cards
    onBackground = Black,
    error = Red
)

private val DarkColors = darkColorScheme(
    primary = LightPink,
    background = Black,
    surface = MediumPink,
    onPrimary = White,
    onSurface = LightBeige,
    onBackground = LightBeige,
    error = Red
)

@Composable
fun FinalProjectTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors

    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        shapes = Shapes,
        content = content
    )
}


