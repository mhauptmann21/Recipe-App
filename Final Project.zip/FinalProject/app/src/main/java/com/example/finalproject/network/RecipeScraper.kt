package com.example.finalproject.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document

object RecipeScraper {

    suspend fun fetchRecipeDetails(url: String): RecipeDetails = withContext(Dispatchers.IO) {
        try {
            val doc = Jsoup.connect(url).get()
            parseRecipe(doc, url)
        } catch (e: Exception) {
            e.printStackTrace()
            RecipeDetails(
                title = "Unknown",
                description = "Failed to load recipe.",
                imageUrl = null,
                ingredients = emptyList(),
                instructions = emptyList(),
                sourceUrl = url
            )
        }
    }

    private fun parseRecipe(doc: Document, url: String): RecipeDetails {
        // --- Title ---
        val title = doc.selectFirst("h1")?.text()
            ?: doc.selectFirst("meta[property=og:title]")?.attr("content")
            ?: "Untitled Recipe"

        // --- Description ---
        val description = doc.selectFirst("div.recipe-summary, div.recipe-summary p")?.text()
            ?: doc.selectFirst("meta[name=description]")?.attr("content")
            ?: "No description available."

        // --- Image ---
        val imageUrl = doc.selectFirst("meta[property=og:image]")?.attr("content")
            ?: doc.selectFirst("img.recipe-image")?.attr("src")

        // --- Ingredients (tries multiple common selectors) ---
        val ingredients = doc.select("li.ingredients-item, span.ingredients-item-name, li.ingredient, .recipe-ingredients__list-item")
            .mapNotNull { it.text().takeIf { text -> text.isNotBlank() } }

        // --- Instructions ---
        val instructions = doc.select("li.subcontainer.instructions-section-item, .step, .instructions-section-item, ol li")
            .mapNotNull { it.text().takeIf { text -> text.isNotBlank() } }

        return RecipeDetails(
            title = title,
            description = description,
            imageUrl = imageUrl,
            ingredients = ingredients,
            instructions = instructions,
            sourceUrl = url
        )
    }

    data class RecipeDetails(
        val title: String,
        val description: String,
        val imageUrl: String?,
        val ingredients: List<String>,
        val instructions: List<String>,
        val sourceUrl: String
    )
}
