package com.example.finalproject.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.finalproject.model.RecipeEntity
import com.example.finalproject.ui.theme.Black
import com.example.finalproject.ui.theme.DarkPink


@Composable
fun RecipeDetailScreen(
    recipe: RecipeEntity,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        recipe.imageUrl?.let { imageUrl ->
            AsyncImage(
                model = imageUrl,
                contentDescription = recipe.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(250.dp),
                contentScale = ContentScale.Crop
            )
        }

        Text(
            text = recipe.title,
            style = MaterialTheme.typography.titleLarge,
            color = DarkPink,
            modifier = Modifier.padding(top = 16.dp)
        )

        Spacer(modifier = Modifier)

        Text(
            text = "Difficulty: ${recipe.difficulty}",
            style = MaterialTheme.typography.bodyMedium,
            color = Black,
            modifier = Modifier.padding(top = 8.dp)
        )

        Spacer(modifier = Modifier)

        Text(
            text = recipe.description.ifBlank { "No description available." },
            style = MaterialTheme.typography.bodyLarge,
            color = Black,
            modifier = Modifier.padding(top = 16.dp)
        )

        Spacer(modifier = Modifier)

        if (!recipe.ingredients.isNullOrBlank()) {
            Spacer(Modifier.height(16.dp))
            Text("Ingredients", style = MaterialTheme.typography.titleMedium)
            Text(recipe.ingredients)
        }

        if (!recipe.instructions.isNullOrBlank()) {
            Spacer(Modifier.height(16.dp))
            Text("Instructions", style = MaterialTheme.typography.titleMedium)
            Text(recipe.instructions)
        }

        if(!recipe.url.isNullOrEmpty()) {
            Button(
                onClick = {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(recipe.url))
                    context.startActivity(intent)
                },
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Open Recipe Website")
            }
        }
    }
}
