package com.example.finalproject.model


import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recipes")
data class RecipeEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val difficulty: String,
    val imageUrl: String? = null,
    val url: String? = null,
    val ingredients: String? = null,
    val instructions: String? = null,
    val isFavorite: Boolean = false
)
