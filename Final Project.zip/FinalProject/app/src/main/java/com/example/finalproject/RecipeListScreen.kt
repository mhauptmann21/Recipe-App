package com.example.finalproject

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.finalproject.ui.theme.FinalProjectTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.res.colorResource
import androidx.navigation.NavController
import com.example.finalproject.ui.theme.Black
import com.example.finalproject.ui.theme.LightPink
import com.example.finalproject.ui.theme.White
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.finalproject.ui.screens.RecipeDetailScreen
import androidx.compose.material3.Icon
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.produceState
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import coil.compose.rememberAsyncImagePainter
import com.example.finalproject.data.FavoritesRepository
import com.example.finalproject.data.RecipeDatabase
import com.example.finalproject.model.RecipeEntity
import com.example.finalproject.data.RecipeRepository
import com.example.finalproject.data.UserPreferenceRepository
import com.example.finalproject.ui.RecipeViewModel
import com.example.finalproject.ui.screens.AddRecipeScreen
import com.example.finalproject.ui.screens.FavoritesScreen
import com.example.finalproject.ui.screens.HelpScreen
import com.example.finalproject.ui.screens.SettingScreen



class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FinalProjectTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    RecipeApp()
                }
            }
        }
    }
}

@Composable
fun RecipeApp() {
    val context = LocalContext.current
    val db = remember { RecipeDatabase.getDatabase(context) }
    val recipeDao = db.recipeDao()

    val navController = rememberNavController()

    val favoritesRepository = remember { FavoritesRepository(db.recipeDao()) }

    val application = LocalContext.current.applicationContext as RecipeApplication
    val recipeViewModel: RecipeViewModel = viewModel()

    Scaffold(
        topBar = {
            val backStackEntry = navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry.value?.destination?.route
            val showBackButton = currentRoute?.startsWith("recipeDetail") == true ||
                    currentRoute == "settings" ||
                    currentRoute == "help" ||
                    currentRoute == "favorites" ||
                    currentRoute == "addRecipe"

            RecipeAppTopBar(navController = navController, showBackButton = showBackButton)
        },
        bottomBar = {
            BottomNavigationBar(navController)
        }
    ) { innerPadding ->

        NavHost(
            navController = navController,
            startDestination = "recipeList",
            modifier = Modifier.padding(innerPadding)
        ){
            composable("recipeList") {
                RecipeList(
                    recipeViewModel = recipeViewModel,
                    favoritesRepository = favoritesRepository,
                    onRecipeDoubleClick = { recipe ->
                        navController.navigate("recipeDetail/${recipe.id}")
                    }
                )
            }
            composable("favorites") {
                FavoritesScreen(
                    recipeViewModel,
                    favoritesRepository,
                    { recipe ->
                        navController.navigate("recipeDetail/${recipe.id}")
                    },
                    Modifier
                )
            }
            composable("recipeDetail/{recipeId}") { backStackEntry ->
                val recipeId = backStackEntry.arguments?.getString("recipeId")?.toIntOrNull()
                var recipe by remember { mutableStateOf<RecipeEntity?>(null) }
                var isLoading by remember { mutableStateOf(true) }

                LaunchedEffect(recipeId) {
                    if (recipeId != null) {
                        val loaded = recipeViewModel.getRecipeById(recipeId)
                        recipe = loaded
                    }
                    isLoading = false
                }

                when {
                    isLoading -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    }

                    recipe != null -> {
                        RecipeDetailScreen(recipe!!)
                    }

                    else -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Recipe not found or failed to load.")
                        }
                    }
                }
            }
            composable("settings") {
                val context = LocalContext.current
                val userPreferenceRepository = remember { UserPreferenceRepository(context) }
                SettingScreen(userPreferenceRepository)
            }
            composable("help") {
                HelpScreen(navController)
            }
            composable("addRecipe") {
                AddRecipeScreen(
                    navController = navController,
                    onAddRecipe = { title, url ->
                        recipeViewModel.addRecipeFromUrl(title, url)
                    }
                )
            }
         }
     }
}

@Composable
fun RecipeList(
    recipeViewModel: RecipeViewModel = viewModel(),
    favoritesRepository: FavoritesRepository,
    onRecipeDoubleClick: (RecipeEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val recipes by recipeViewModel.recipes.collectAsState(initial = emptyList())
    val favorites by favoritesRepository.favorites.collectAsState(initial = emptyList())

    LazyColumn(modifier = modifier) {
        items(recipes) { recipe ->
            val isFavorite = favorites.any { it.id == recipe.id }

            RecipeCard(
                recipe = recipe,
                onDoubleClick = { onRecipeDoubleClick(recipe) },
                onToggleFavorite = { recipeViewModel.toggleFavorite(recipe) },
                isFavorite = isFavorite,
                modifier = Modifier.padding(12.dp)
            )
        }
    }
}



@Composable
fun RecipeCard(
    recipe: RecipeEntity,
    onDoubleClick: () -> Unit,
    onToggleFavorite: (RecipeEntity) -> Unit,
    isFavorite: Boolean,
    modifier: Modifier = Modifier
) {
    // Keeps track of expanded/collapsed state
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize( // Smooth height animation
                animationSpec = tween(
                    durationMillis = 300,
                    easing = LinearOutSlowInEasing
                )
            )
            .combinedClickable(
                onClick = { expanded = !expanded }, // Toggle on click
                onDoubleClick = { onDoubleClick() }
            ),

        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = colorResource(id = R.color.white))
    ) {
        Column {
            // Image
            AsyncImage(
                model = recipe.imageUrl,
                contentDescription = recipe.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(194.dp),
                contentScale = ContentScale.Crop
            )

            // Title row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = recipe.title,
                    style = MaterialTheme.typography.bodyLarge,
                    color = colorResource(id = R.color.dark_pink)
                )

                IconButton(onClick = { onToggleFavorite(recipe) }) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Toggle Favorite",
                        tint = if (isFavorite) colorResource(id = R.color.medium_pink) else colorResource(id = R.color.black)
                    )
                }
            }

            // Expandable description
            if (expanded) {
                Text(
                    text = recipe.difficulty, // e.g. "Easy", "Intermediate", "Hard"
                    color = when (recipe.difficulty) {
                        "Easy" -> colorResource(id = R.color.green)
                        "Intermediate" -> colorResource(id = R.color.yellow)
                        "Hard" -> colorResource(id = R.color.red)
                        else -> Black
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding((16.dp))
                )
                if(recipe.description.isNotEmpty()){
                    Text(
                        text = recipe.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Black,
                        modifier = Modifier.padding(16.dp)
                    )
                }

                if (!recipe.url.isNullOrEmpty()) {
                    Text(
                        text = "URL: ${recipe.url}",
                        style = MaterialTheme.typography.bodySmall,
                        color = colorResource(id = R.color.medium_pink),
                        modifier = Modifier.padding(16.dp)
                    )
                }

            }
        }
    }
}




@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecipeAppTopBar(
    navController: NavController,
    showBackButton: Boolean = false,
    modifier: Modifier = Modifier
) {
    TopAppBar(
        title = {
            Text(
                text = stringResource(id = R.string.app_name),
                style = MaterialTheme.typography.titleLarge,
                color = White
            )
        },
        navigationIcon = {
            if (showBackButton) {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = White
                    )
                }
            }
        },
        actions = {
            IconButton(onClick = { navController.navigate("favorites") }) {
                Icon(
                    Icons.Default.Favorite,
                    contentDescription = "Favorites",
                    tint = White
                )
            }
            IconButton(onClick = { navController.navigate("addRecipe") }) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = "Add Recipe",
                    tint = White
                )
            }
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = LightPink, // background
            titleContentColor = White    // title text (redundant but safe)
        ),
        modifier = modifier
    )
}

@Composable
fun BottomNavigationBar(navController: NavController) {
    NavigationBar(containerColor = LightPink) {
        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("recipeList")},
            icon = { Icon(Icons.Default.Home, contentDescription = "Home", tint = White)},
            label = { Text("Home", color = White) }
        )

        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("favorites") },
            icon = { Icon(Icons.Default.Favorite, contentDescription = "Favorites", tint = White) },
            label = { Text("Favorites", color = White)}
        )

        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("settings") },
            icon = { Icon(Icons.Default.Settings, contentDescription = "Settings", tint = White) },
            label = { Text("Settings", color = White)}
        )

        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("help") },
            icon = { Icon(Icons.Default.Info, contentDescription = "Help", tint = White) },
            label = { Text("Help", color = White)}
        )
    }
}

